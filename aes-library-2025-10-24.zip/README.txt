AES Library #1 - Speed-Oriented Implementation
Version: 2025.10.24 (Stable)

Build Instructions:
    clang test.c aes.c -O3 -std=c99 -o test
    ./test

Description:
    - AES-128/192/256 supported
    - Operation Modes: CTR / CBC / ECB
    - Padding: PKCS#7, ANSI X9.23, None
    - Performance Benchmark: 10MB encryption timing
    - Tested: macOS / Linux / Windows (MinGW)
